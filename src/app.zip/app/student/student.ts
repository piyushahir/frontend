

export class Student {
    student_id:number;
     student_name: string;
     gender: string;
     qualification: string;
     email: string;
     contact_no: string;
    //  studentEnrolls: [
    //     {
    //         enroll_id: number;
    //         reg_date: string;
    //         feedback: string,
    //         payment: number;
    //     }
    // ];
     password: string;
     confirm_password: string;
     student_address: string;

    
    
    constructor() {}
    
    


}

